
def fake_model(age):
	if age > 5:

		predction ="Yes Survived"
	else:

		predction ="Not Survived"
	return predction